import gleam/list

pub fn square(x: Int) -> Int {
  list.range(3, x)
  |> list.map(fn(x) { x * x })
  |> list.fold(0, fn(acc, x) { acc + x })
}

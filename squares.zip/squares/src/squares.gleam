import gleam/float
import gleam/int
import gleam/io

// import root
import sq_utils

pub fn main() {
  let sq = sq_utils.square(4)
  io.println(int.to_string(sq))
  let rt = root(int.to_float(sq))
  // let rt = root.squareroot(int.to_float(sq))
  io.println(float.to_string(rt))
}

@external(erlang, "math", "sqrt")
pub fn root(x: Float) -> Float

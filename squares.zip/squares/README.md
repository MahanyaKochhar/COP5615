# squares

[![Package Version](https://img.shields.io/hexpm/v/squares)](https://hex.pm/packages/squares)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/squares/)

```sh
gleam add squares@1
```
```gleam
import squares

pub fn main() -> Nil {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/squares>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```

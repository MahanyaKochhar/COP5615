# test3

[![Package Version](https://img.shields.io/hexpm/v/test3)](https://hex.pm/packages/test3)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/test3/)

```sh
gleam add test3@1
```
```gleam
import test3

pub fn main() -> Nil {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/test3>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
```

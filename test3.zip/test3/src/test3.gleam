import gleam/dict.{type Dict}
import gleam/erlang/process
import gleam/float
import gleam/int
import gleam/io
import gleam/list
import gleam/option.{type Option, None, Some}
import gleam/random
import gleam/result
import gleam/set.{type Set}
import gleam/string

pub type Topology {
  Full
  Grid3D
  Line
  ImperfectGrid3D
}

pub type Algorithm {
  Gossip
  PushSum
}

pub type ActorMessage {
  GossipRumor(rumor: String)
  GossipTerminate

  PushSumValue(s: Float, w: Float)
  PushSumTerminate

  Start
  GetStatus
  StatusResponse(active: Bool)
}

pub type ActorState {
  GossipState(
    id: Int,
    neighbors: List(process.Subject(ActorMessage)),
    rumor_count: Int,
    rumor: Option(String),
    terminated: Bool,
    main_subject: process.Subject(ActorMessage),
  )
  PushSumState(
    id: Int,
    neighbors: List(process.Subject(ActorMessage)),
    s: Float,
    w: Float,
    ratio_history: List(Float),
    consecutive_stable: Int,
    terminated: Bool,
    main_subject: process.Subject(ActorMessage),
  )
}

pub fn main() {
  // Example usage - in real implementation this would parse command line args
  let num_nodes = 100
  let topology = Full
  let algorithm = Gossip

  case run_simulation(num_nodes, topology, algorithm) {
    Ok(time) -> {
      io.println("Convergence time: " <> int.to_string(time) <> " milliseconds")
    }
    Error(msg) -> {
      io.println("Error: " <> msg)
    }
  }
}

// Run the complete simulation
pub fn run_simulation(
  num_nodes: Int,
  topology: Topology,
  algorithm: Algorithm,
) -> Result(Int, String) {
  let start_time = get_current_time_millis()

  // Create actors
  let actors = create_actors(num_nodes, algorithm)

  // Build topology
  let actors_with_topology = case build_topology(actors, topology) {
    Ok(actors) -> actors
    Error(msg) -> {
      io.println("Failed to build topology: " <> msg)
      []
    }
  }

  // Start the protocol
  case algorithm {
    Gossip -> start_gossip_protocol(actors_with_topology)
    PushSum -> start_push_sum_protocol(actors_with_topology)
  }

  // Wait for convergence
  wait_for_convergence(actors_with_topology)

  let end_time = get_current_time_millis()
  Ok(end_time - start_time)
}

// Create actors based on algorithm type
fn create_actors(
  num_nodes: Int,
  algorithm: Algorithm,
) -> List(process.Subject(ActorMessage)) {
  case algorithm {
    Gossip -> create_gossip_actors(num_nodes)
    PushSum -> create_push_sum_actors(num_nodes)
  }
}

// Create gossip actors
fn create_gossip_actors(num_nodes: Int) -> List(process.Subject(ActorMessage)) {
  list.range(0, num_nodes - 1)
  |> list.map(fn(id) {
    process.start(
      fn() { gossip_actor_loop(id, [], 0, None, False, process.new_subject()) },
      True,
    )
  })
}

// Create push-sum actors  
fn create_push_sum_actors(num_nodes: Int) -> List(process.Subject(ActorMessage)) {
  list.range(0, num_nodes - 1)
  |> list.map(fn(id) {
    let s = int.to_float(id)
    process.start(
      fn() {
        push_sum_actor_loop(id, [], s, 1.0, [], 0, False, process.new_subject())
      },
      True,
    )
  })
}

// Build network topology
fn build_topology(
  actors: List(process.Subject(ActorMessage)),
  topology: Topology,
) -> Result(List(process.Subject(ActorMessage)), String) {
  let num_nodes = list.length(actors)

  case topology {
    Full -> build_full_topology(actors)
    Grid3D -> build_3d_grid_topology(actors)
    Line -> build_line_topology(actors)
    ImperfectGrid3D -> build_imperfect_3d_grid_topology(actors)
  }
}

// Full topology - every actor connected to every other
fn build_full_topology(
  actors: List(process.Subject(ActorMessage)),
) -> Result(List(process.Subject(ActorMessage)), String) {
  // Send neighbor lists to each actor
  list.each(actors, fn(actor) {
    let neighbors = list.filter(actors, fn(other) { actor != other })
    process.send(actor, SetNeighbors(neighbors))
  })
  Ok(actors)
}

// 3D Grid topology
fn build_3d_grid_topology(
  actors: List(process.Subject(ActorMessage)),
) -> Result(List(process.Subject(ActorMessage)), String) {
  let num_nodes = list.length(actors)
  let cube_size = calculate_cube_size(num_nodes)

  let actors_array = list.to_array(actors)

  list.index_map(actors, fn(actor, index) {
    let neighbors = get_3d_grid_neighbors(index, cube_size, actors_array)
    process.send(actor, SetNeighbors(neighbors))
  })

  Ok(actors)
}

// Line topology  
fn build_line_topology(
  actors: List(process.Subject(ActorMessage)),
) -> Result(List(process.Subject(ActorMessage)), String) {
  list.index_map(actors, fn(actor, index) {
    let neighbors = get_line_neighbors(index, list.length(actors), actors)
    process.send(actor, SetNeighbors(neighbors))
  })
  Ok(actors)
}

// Imperfect 3D Grid topology
fn build_imperfect_3d_grid_topology(
  actors: List(process.Subject(ActorMessage)),
) -> Result(List(process.Subject(ActorMessage)), String) {
  let num_nodes = list.length(actors)
  let cube_size = calculate_cube_size(num_nodes)

  let actors_array = list.to_array(actors)

  list.index_map(actors, fn(actor, index) {
    let grid_neighbors = get_3d_grid_neighbors(index, cube_size, actors_array)
    let random_neighbor = get_random_actor(actors, actor)
    let all_neighbors = case random_neighbor {
      Some(neighbor) -> [neighbor, ..grid_neighbors]
      None -> grid_neighbors
    }
    process.send(actor, SetNeighbors(all_neighbors))
  })

  Ok(actors)
}

// Helper functions for topology building
fn calculate_cube_size(num_nodes: Int) -> Int {
  // Find the smallest cube that fits num_nodes
  let size = float.ceiling(float.power(int.to_float(num_nodes), 1.0 /. 3.0))
  float.truncate(size)
}

fn get_3d_grid_neighbors(
  index: Int,
  cube_size: Int,
  actors_array,
) -> List(process.Subject(ActorMessage)) {
  let x = index % cube_size
  let y = #(index / cube_size) % cube_size
  let z = index / #(cube_size * cube_size)

  let directions = [
    #(-1, 0, 0),
    #(1, 0, 0),
    // left, right
    #(0, -1, 0),
    #(0, 1, 0),
    // up, down  
    #(0, 0, -1),
    #(0, 0, 1),
    // front, back
  ]

  directions
  |> list.filter_map(fn(dir) {
    let #(dx, dy, dz) = dir
    let new_x = x + dx
    let new_y = y + dy
    let new_z = z + dz

    case
      new_x >= 0
      && new_x < cube_size
      && new_y >= 0
      && new_y < cube_size
      && new_z >= 0
      && new_z < cube_size
    {
      True -> {
        let neighbor_index =
          new_z * cube_size * cube_size + new_y * cube_size + new_x
        array.get(actors_array, neighbor_index)
      }
      False -> None
    }
  })
}

fn get_line_neighbors(
  index: Int,
  total: Int,
  actors: List(process.Subject(ActorMessage)),
) -> List(process.Subject(ActorMessage)) {
  let actors_array = list.to_array(actors)

  let neighbors = []

  // Left neighbor
  let neighbors = case index > 0 {
    True ->
      case array.get(actors_array, index - 1) {
        Some(neighbor) -> [neighbor, ..neighbors]
        None -> neighbors
      }
    False -> neighbors
  }

  // Right neighbor  
  let neighbors = case index < total - 1 {
    True ->
      case array.get(actors_array, index + 1) {
        Some(neighbor) -> [neighbor, ..neighbors]
        None -> neighbors
      }
    False -> neighbors
  }

  neighbors
}

fn get_random_actor(
  actors: List(process.Subject(ActorMessage)),
  exclude: process.Subject(ActorMessage),
) -> Option(process.Subject(ActorMessage)) {
  let available = list.filter(actors, fn(actor) { actor != exclude })
  case available {
    [] -> None
    [single] -> Some(single)
    multiple -> {
      let index = random.int_range(0, list.length(multiple))
      list.at(multiple, index)
    }
  }
}

// Gossip actor implementation
fn gossip_actor_loop(
  id: Int,
  neighbors: List(process.Subject(ActorMessage)),
  rumor_count: Int,
  rumor: Option(String),
  terminated: Bool,
  main_subject: process.Subject(ActorMessage),
) -> Nil {
  case terminated {
    True -> Nil
    False -> {
      let message = process.receive(main_subject, 100)

      case message {
        Ok(GossipRumor(new_rumor)) -> {
          let new_count = rumor_count + 1
          let updated_rumor = Some(new_rumor)

          // Spread rumor to random neighbor if not terminated
          case new_count < 10 && !list.is_empty(neighbors) {
            True -> {
              let random_index = random.int_range(0, list.length(neighbors))
              case list.at(neighbors, random_index) {
                Ok(neighbor) -> process.send(neighbor, GossipRumor(new_rumor))
                Error(_) -> Nil
              }
            }
            False -> Nil
          }

          let new_terminated = new_count >= 10
          gossip_actor_loop(
            id,
            neighbors,
            new_count,
            updated_rumor,
            new_terminated,
            main_subject,
          )
        }

        Ok(Start) -> {
          // Start spreading if we have a rumor
          case rumor {
            Some(r) -> {
              case !list.is_empty(neighbors) {
                True -> {
                  let random_index = random.int_range(0, list.length(neighbors))
                  case list.at(neighbors, random_index) {
                    Ok(neighbor) -> process.send(neighbor, GossipRumor(r))
                    Error(_) -> Nil
                  }
                }
                False -> Nil
              }
            }
            None -> Nil
          }
          gossip_actor_loop(
            id,
            neighbors,
            rumor_count,
            rumor,
            terminated,
            main_subject,
          )
        }

        Ok(GetStatus) -> {
          process.send(main_subject, StatusResponse(!terminated))
          gossip_actor_loop(
            id,
            neighbors,
            rumor_count,
            rumor,
            terminated,
            main_subject,
          )
        }

        Ok(SetNeighbors(new_neighbors)) -> {
          gossip_actor_loop(
            id,
            new_neighbors,
            rumor_count,
            rumor,
            terminated,
            main_subject,
          )
        }

        Error(_) -> {
          // Timeout - continue periodic spreading if active
          case
            !terminated && option.is_some(rumor) && !list.is_empty(neighbors)
          {
            True -> {
              let random_index = random.int_range(0, list.length(neighbors))
              case list.at(neighbors, random_index) {
                Ok(neighbor) -> {
                  case rumor {
                    Some(r) -> process.send(neighbor, GossipRumor(r))
                    None -> Nil
                  }
                }
                Error(_) -> Nil
              }
            }
            False -> Nil
          }
          gossip_actor_loop(
            id,
            neighbors,
            rumor_count,
            rumor,
            terminated,
            main_subject,
          )
        }

        _ ->
          gossip_actor_loop(
            id,
            neighbors,
            rumor_count,
            rumor,
            terminated,
            main_subject,
          )
      }
    }
  }
}

// Push-sum actor implementation  
fn push_sum_actor_loop(
  id: Int,
  neighbors: List(process.Subject(ActorMessage)),
  s: Float,
  w: Float,
  ratio_history: List(Float),
  consecutive_stable: Int,
  terminated: Bool,
  main_subject: process.Subject(ActorMessage),
) -> Nil {
  case terminated {
    True -> Nil
    False -> {
      let message = process.receive(main_subject, 100)

      case message {
        Ok(PushSumValue(recv_s, recv_w)) -> {
          let new_s = s +. recv_s
          let new_w = w +. recv_w
          let current_ratio = new_s /. new_w

          // Check for convergence
          let new_history = [current_ratio, ..list.take(ratio_history, 2)]
          let new_consecutive =
            check_push_sum_convergence(new_history, consecutive_stable)
          let new_terminated = new_consecutive >= 3

          // Send half to random neighbor
          case !new_terminated && !list.is_empty(neighbors) {
            True -> {
              let send_s = new_s /. 2.0
              let send_w = new_w /. 2.0
              let keep_s = new_s -. send_s
              let keep_w = new_w -. send_w

              let random_index = random.int_range(0, list.length(neighbors))
              case list.at(neighbors, random_index) {
                Ok(neighbor) ->
                  process.send(neighbor, PushSumValue(send_s, send_w))
                Error(_) -> Nil
              }

              push_sum_actor_loop(
                id,
                neighbors,
                keep_s,
                keep_w,
                new_history,
                new_consecutive,
                new_terminated,
                main_subject,
              )
            }
            False -> {
              push_sum_actor_loop(
                id,
                neighbors,
                new_s,
                new_w,
                new_history,
                new_consecutive,
                new_terminated,
                main_subject,
              )
            }
          }
        }

        Ok(Start) -> {
          // Start by sending half to random neighbor
          case !list.is_empty(neighbors) {
            True -> {
              let send_s = s /. 2.0
              let send_w = w /. 2.0
              let keep_s = s -. send_s
              let keep_w = w -. send_w

              let random_index = random.int_range(0, list.length(neighbors))
              case list.at(neighbors, random_index) {
                Ok(neighbor) ->
                  process.send(neighbor, PushSumValue(send_s, send_w))
                Error(_) -> Nil
              }

              push_sum_actor_loop(
                id,
                neighbors,
                keep_s,
                keep_w,
                ratio_history,
                consecutive_stable,
                terminated,
                main_subject,
              )
            }
            False -> {
              push_sum_actor_loop(
                id,
                neighbors,
                s,
                w,
                ratio_history,
                consecutive_stable,
                terminated,
                main_subject,
              )
            }
          }
        }

        Ok(GetStatus) -> {
          process.send(main_subject, StatusResponse(!terminated))
          push_sum_actor_loop(
            id,
            neighbors,
            s,
            w,
            ratio_history,
            consecutive_stable,
            terminated,
            main_subject,
          )
        }

        Ok(SetNeighbors(new_neighbors)) -> {
          push_sum_actor_loop(
            id,
            new_neighbors,
            s,
            w,
            ratio_history,
            consecutive_stable,
            terminated,
            main_subject,
          )
        }

        Error(_) -> {
          // Timeout - continue periodic sending if active
          case !terminated && !list.is_empty(neighbors) {
            True -> {
              let send_s = s /. 2.0
              let send_w = w /. 2.0
              let keep_s = s -. send_s
              let keep_w = w -. send_w

              let random_index = random.int_range(0, list.length(neighbors))
              case list.at(neighbors, random_index) {
                Ok(neighbor) ->
                  process.send(neighbor, PushSumValue(send_s, send_w))
                Error(_) -> Nil
              }

              push_sum_actor_loop(
                id,
                neighbors,
                keep_s,
                keep_w,
                ratio_history,
                consecutive_stable,
                terminated,
                main_subject,
              )
            }
            False -> {
              push_sum_actor_loop(
                id,
                neighbors,
                s,
                w,
                ratio_history,
                consecutive_stable,
                terminated,
                main_subject,
              )
            }
          }
        }

        _ ->
          push_sum_actor_loop(
            id,
            neighbors,
            s,
            w,
            ratio_history,
            consecutive_stable,
            terminated,
            main_subject,
          )
      }
    }
  }
}

// Check push-sum convergence
fn check_push_sum_convergence(
  ratio_history: List(Float),
  current_consecutive: Int,
) -> Int {
  case ratio_history {
    [r1, r2, r3, ..] -> {
      let diff1 = float.absolute_value(r1 -. r2)
      let diff2 = float.absolute_value(r2 -. r3)
      let threshold = 1.0e-10

      case diff1 < threshold && diff2 < threshold {
        True -> current_consecutive + 1
        False -> 0
      }
    }
    _ -> 0
  }
}

// Protocol starters
fn start_gossip_protocol(actors: List(process.Subject(ActorMessage))) -> Nil {
  case actors {
    [first, ..] -> {
      process.send(first, GossipRumor("Hello World"))
      process.send(first, Start)
    }
    [] -> Nil
  }
}

fn start_push_sum_protocol(actors: List(process.Subject(ActorMessage))) -> Nil {
  case actors {
    [first, ..] -> process.send(first, Start)
    [] -> Nil
  }
}

// Wait for convergence
fn wait_for_convergence(actors: List(process.Subject(ActorMessage))) -> Nil {
  wait_for_convergence_loop(actors, 0)
}

fn wait_for_convergence_loop(
  actors: List(process.Subject(ActorMessage)),
  iterations: Int,
) -> Nil {
  case iterations > 1000 {
    True -> {
      io.println("Timeout waiting for convergence")
      Nil
    }
    False -> {
      // Check if all actors are terminated
      let active_count = count_active_actors(actors)
      case active_count {
        0 -> Nil
        // All terminated
        _ -> {
          process.sleep(100)
          // Wait 100ms
          wait_for_convergence_loop(actors, iterations + 1)
        }
      }
    }
  }
}

fn count_active_actors(actors: List(process.Subject(ActorMessage))) -> Int {
  actors
  |> list.map(fn(actor) {
    process.send(actor, GetStatus)
    case process.receive_forever() {
      StatusResponse(active) ->
        case active {
          True -> 1
          False -> 0
        }
      _ -> 0
    }
  })
  |> list.fold(0, int.add)
}

// Helper function to get current time (simplified)
fn get_current_time_millis() -> Int {
  // In a real implementation, this would use proper time functions
  // For this example, we'll use a placeholder
  1000
}

// Additional message type for setting neighbors
pub type ActorMessage2 {
  // ... existing messages ...
  SetNeighbors(neighbors: List(process.Subject(ActorMessage)))
}

import minigen

pub type Profile {
  Profile(num: Int)
}

pub fn main() -> Profile {
  let gen_num = minigen.integer(600)
  let profile_gen = minigen.map(gen_num, fn(num) { Profile(num: num) })
  echo minigen.run(profile_gen)
}
